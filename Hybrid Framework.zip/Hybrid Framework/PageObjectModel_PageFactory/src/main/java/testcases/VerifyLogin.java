package testcases;

import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;

public class VerifyLogin extends BaseClass{

	@Test(dataProvider = "fetchData")
	public void runVerifyLogin() {
		System.out.println(driver);
		LoginPage lp = new LoginPage(driver);
		
		lp.enterUserName()
		.enterPassword()
		.clickLogin()
		.verifyHomePage()
		.clickCRMSFA();
		
	}
}
