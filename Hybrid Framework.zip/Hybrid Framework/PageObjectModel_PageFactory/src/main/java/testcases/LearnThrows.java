package testcases;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class LearnThrows {

	public static void main(String[] args) throws FileNotFoundException {
		FileInputStream fis = new FileInputStream(new File(""));
		
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
