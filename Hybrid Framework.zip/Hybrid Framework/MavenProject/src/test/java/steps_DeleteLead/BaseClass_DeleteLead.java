package steps_DeleteLead;

import org.openqa.selenium.chrome.ChromeDriver;

public class BaseClass_DeleteLead {
public static ChromeDriver driver;
}
