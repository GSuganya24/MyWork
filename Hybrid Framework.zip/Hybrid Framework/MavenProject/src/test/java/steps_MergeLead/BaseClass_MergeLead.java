package steps_MergeLead;

import org.openqa.selenium.chrome.ChromeDriver;

public class BaseClass_MergeLead {
	public static ChromeDriver driver;
}
