package steps_DuplicateLead;

import org.openqa.selenium.chrome.ChromeDriver;

public class BaseClass_DuplicateLead {
	
public static ChromeDriver driver;
}
