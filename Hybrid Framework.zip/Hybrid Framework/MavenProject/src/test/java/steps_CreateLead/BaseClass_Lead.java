package steps_CreateLead;

import org.openqa.selenium.chrome.ChromeDriver;

public class BaseClass_Lead {
	
public static ChromeDriver driver;
}
