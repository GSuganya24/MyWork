package week3.day2;

public class Desktop implements Software{
		

	public void hardwareResources() {
		System.out.println("Hardware");
		
	}

	public void softwareResources() {
		System.out.println("Software");
		
	}
	
	public void desktopModel() {
		System.out.println("The desktop model is latest");
	}
public static void main(String[] args) {
	Desktop desk = new Desktop();
		desk.hardwareResources();
		desk.softwareResources();
		desk.desktopModel();
}
}
