package week3.day2;

public class College extends University {

	@Override
	public void ug() {
		System.out.println("Umimplemented method");
		
	}
	
public static void main(String[] args) {
	College col = new College();
	col.ug();
	col.pg();
	//System.out.println(("helo").toUpperCase());
}
}
