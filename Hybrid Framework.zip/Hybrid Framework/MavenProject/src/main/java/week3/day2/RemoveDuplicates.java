package week3.day2;

import java.util.HashSet;
import java.util.Set;

public class RemoveDuplicates {
	public static void main(String[] args) {
		String name = "PayPal India";
		name = name.replace(" ","");
		char[] chArray = name.toCharArray();
		//Converting Character  to set as charset
		Set<Character> charSet = new HashSet<Character>();
		//Converting Character  to set as charset
		Set<Character> dupSet = new HashSet<Character>();
		for (char eachChar : chArray) {
			boolean add = charSet.add(eachChar);
			if(!add) {
				dupSet.add(eachChar);
			}
		}
		System.out.println(dupSet);
		//Check the dupCharSet elements and remove those in the charSet
		charSet.removeAll(dupSet);
		System.out.println(charSet);
	}

}
