package week3.day2;

public abstract class MultipleLangauge implements TestTool {
	public void ruby() {
		System.out.println("The language is ruby");
	}
	public abstract void python();

}
