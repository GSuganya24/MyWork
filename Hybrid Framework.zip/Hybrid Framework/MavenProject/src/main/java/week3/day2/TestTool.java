package week3.day2;

public interface TestTool extends Language {
	public void selenium();

}
