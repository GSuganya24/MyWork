package week3.day2;

public interface Software extends Hardware{
	void softwareResources();

}
