package week3.day2;

import java.util.Arrays;
import java.util.List;

public class SortingUsingCollection {
	public static void main(String[] args) {
		String[] input = {"HCL","Wipro","Aspire Systems","CTS"};
		//sort the array
				Arrays.sort(input);
		//Length of the array using list
		List<String> companies = Arrays.asList(input);//Arrays.asList --> ctrl+space
		int len = input.length;
		int l = companies.size();
		System.out.println("Length : " +l);
		for(String eachcomp : companies ) { //foreach loop
			System.out.println(eachcomp);
		}
		for(int i = 0; i<len; i++) {
			System.out.println(input[i]);
		}
	}
}
