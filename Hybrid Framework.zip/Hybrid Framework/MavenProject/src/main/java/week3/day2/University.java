package week3.day2;

public abstract class University {
           public void pg() {
        	   System.out.println("Implemented class");
           }
           public abstract void ug();
           
}
