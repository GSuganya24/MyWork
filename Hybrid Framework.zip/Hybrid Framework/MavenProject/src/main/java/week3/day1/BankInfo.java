package week3.day1;

public class BankInfo {
	public void savings() {
		System.out.println("The min.balance of the savings account should be 500");
	}
	public void fixed() {
		System.out.println("The interest rate of fixed deposit ranges between 4% and 5.3%");
	}
	public void deposit() {
		System.out.println("The person can deposit a minimum of 1Lakh on a single day online without commission");
	}
}
