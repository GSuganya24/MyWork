package week3.day1;

public class Calculator {
	public void add(int a, int b) {
	  int sum;
		sum = a+b;
		System.out.println("sum 1 = " +sum);
	}
	public void add(int a, int b, int c) {
		int sum = a+b+c;
		System.out.println("sum 2 = "+sum);
	}
	public void multiply(int a, int b) {
		int result = a*b;
		System.out.println("Multiply 1 = "+result);
	}
	public void multiply(int a, double b) {
	   double  result = a*b;
		System.out.println("Multiply 2 = "+result);
	}
	public void sub(int a, int b) {
		int result = a-b;
		System.out.println("Sub1 = "+result);
	}
	public void sub(double a, double b) {
		double result = a-b;
		System.out.println("Sub2 = "+result);
	}
	public void div(int a,int b) {
		int result = a/b;
		System.out.println("Div1 = "+result);
	}
	public void div(double a, int b) {
		double result = a/b;
		System.out.println("Div2 = "+result);
	}
	public static void main(String[] args) {
		Calculator cal = new Calculator();
		cal.add(5, 4);
		cal.add(10,15,7);
		cal.sub(17,12);
		cal.sub(15.5,12.3);
		cal.div(15, 5);
		cal.div(18.9, 9);
		cal.multiply(5, 8);
		cal.multiply(6,3.2);
	}
	
	
	
	
	

}
