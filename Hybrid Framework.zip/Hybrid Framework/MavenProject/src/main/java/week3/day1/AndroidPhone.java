package week3.day1;

public class AndroidPhone extends SmartPhone{
		public void takeVideo() { 
			System.out.println("Video is running");
		}
		protected void sendMsg() { //Method Overriding
			System.out.println("Sending message");
		}
		public static void main(String[] args) {
			AndroidPhone phone = new AndroidPhone();
			phone.sendMsg();
			phone.makeCall();
			phone.saveContact();
			phone.accessWhatsapp();
			phone.takeVideo();
			SmartPhone ph = new SmartPhone();
			ph.takeVideo();
		}
}
