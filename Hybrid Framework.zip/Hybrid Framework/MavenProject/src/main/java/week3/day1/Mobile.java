package week3.day1;

public class Mobile {
	protected void sendMsg() { //Wihtin the package it is accessed without keyword extends
		System.out.println("Message Sent");
	}
	public void makeCall() {
		System.out.println("Calling..");
	}
	public void saveContact() {
		System.out.println("Contact Saved");
	}

}
