package week3.day1;

public class SmartPhone extends Mobile {
        public void accessWhatsapp() {
        	System.out.println("Whatsapp is accessible");
        }
        public void takeVideo() {
        	System.out.println("Taking Video");
        }
        public static void main(String[] args) {
			SmartPhone ph = new SmartPhone();
			ph.takeVideo();
		}
       
}
