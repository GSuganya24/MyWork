package week8.day1;

public class FibonacciSeries {
	public static void main(String[] args) {
		String str = "My name is Suganya";
		str = str.replaceAll(" ", "");
		char[] charArray = str.toCharArray();
		System.out.println(charArray);
		int i,j,max = 0;
		int count =0;
		for(i=0;i<charArray.length;i++) {
			for(j=i+1;j<charArray.length;j++) {
				if(charArray[i]==(charArray[j])) {
					count++;
					max = count;
				}
				System.out.println(max);
			}
			count = 0;
			
		}
	}

}
