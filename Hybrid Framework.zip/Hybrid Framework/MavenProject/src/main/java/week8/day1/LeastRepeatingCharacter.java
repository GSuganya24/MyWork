package week8.day1;

public class LeastRepeatingCharacter {
	public static void main(String[] args) {
//		String s1 = "abc how are you \"let you\" talk back \"later from the\" please reach me";
		String s = "Hello hworld";
		
		char maxChar = '\u0000';
		s = s.toLowerCase();
		char[] charArray =  s.toCharArray();
		System.out.println(charArray);
		int count = 0,min = 1;

		for(int i=0;i<charArray.length;i++) {
			for(int j=0;j<charArray.length;j++) {
				if(charArray[i] == charArray[j] && charArray[i] != ' ') {
					count++;
				}
			}
			if(min<=count) {
				min = count;
				maxChar  = charArray[i];
			}
			count=0;
		}
		System.out.println(maxChar);
		System.out.println(min);
		
		
	}
}
8889