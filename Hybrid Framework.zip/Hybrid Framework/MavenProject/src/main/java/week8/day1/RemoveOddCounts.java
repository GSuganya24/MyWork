package week8.day1;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class RemoveOddCounts {
	public static void main(String[] args) {
		int[] arr = {0,1,1,1,3,3,3,3,5,5,67
				,67,7,4,4,8,8,8,8,9};
		Arrays.sort(arr);
		int l = arr.length;
		int count = 0;
		Set <Integer> check = new HashSet<Integer>();
		List <Integer> result = new ArrayList<Integer>();
		for (int i=0;i<l;i++) {
//			int b = arr[i];
			for( int j=0;j<l;j++) {
				if(arr[j] == arr[i]) {
					boolean value = check.add(arr[i]);
					if (value == true) {
						result.add(arr[i]);
						count = 0;
					}
						else {
							count = count + 1;
						}
				if(count == 1) {
					result.add(arr[i]);
				}
					}		
		}
		}
		System.out.println(result);
		
	}
		

}
