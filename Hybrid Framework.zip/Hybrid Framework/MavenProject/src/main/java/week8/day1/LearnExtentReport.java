package week8.day1;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class LearnExtentReport {
	public static void main(String[] args) {
		//Set up the physical path for report
		ExtentHtmlReporter reporter = new ExtentHtmlReporter("./reports/result.html");
		
		//To keep report history
		reporter.setAppendExisting(true);
		
		//Create object for extend reports
		ExtentReports extent = new ExtentReports();
		
		//Attach data with physical report
		extent.attachReporter(reporter);
		
		//Create a testcase
		ExtentTest test = extent.createTest("CreateLead","Create Lead with Mandatory fields");
		
		//Assign author and category
		test.assignAuthor("Suganya");
		test.assignCategory("Smoke");
		
		//Providing step level status
		test.pass("Enter username");
		test.pass("Enter password");
		test.fail("Click Login");
		
		//Flush report(Mandatory)
		extent.flush();
		
		
	}

}

