package week8.day1;


public class LearnException {
	public static void main(String[] args) {
		int a = 10;
		int b = 0;
		int c[] = {2,4,5};
		try {
			System.out.println(a/b);
			System.out.println(c[3]);
			}catch (ArithmeticException e) {
				if(b==0) {
					System.out.println(a/1);
				}
				System.out.println(e);
			}catch (ArrayIndexOutOfBoundsException e) {
				System.out.println(e);
			}catch (Exception e) {
				System.out.println(e);
			}finally {
				System.out.println(a/5);
			}
		System.out.println("End of the Program");
	}

}
