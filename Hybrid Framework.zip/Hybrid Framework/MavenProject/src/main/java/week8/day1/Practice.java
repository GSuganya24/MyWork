package week8.day1;

public class Practice {
	public static void main (String[] args) {
	String s= "Cognizant";
	char[] charArray = s.toCharArray();
	int l = charArray.length;
	for (int i=l;i>0;i--) {
		System.out.print(charArray[i-1]);
	}
	}
}
