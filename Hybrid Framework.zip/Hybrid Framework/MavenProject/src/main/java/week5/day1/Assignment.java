package week5.day1;

import org.testng.annotations.Test;

public class Assignment {
	@Test
	public void a(){
		System.out.println("Method a");
		}
	@Test(dependsOnMethods = "c")
		public void b(){
		System.out.println("Method b");
		}
	@Test(dependsOnMethods="a")
		public void c(){
		System.out.println("Method c");
		}
	@Test
		public void d(){
		System.out.println("Method d");
		}
}
