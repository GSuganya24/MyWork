package week5.day1;


import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;


public class DeleteIncident extends BaseClass_Incident  {
	@Test(enabled = true)
	public void deleteIncident() throws InterruptedException {
//	public static void main(String[] args) throws InterruptedException {
		// Enter the frame
		WebElement search1 = driver.findElement(By.xpath("//input[@class='form-control']"));
		search1.sendKeys(inciNum);
		search1.sendKeys(Keys.ENTER);
		Thread.sleep(1000);
		driver.findElement(By.xpath("//table[@id='incident_table']/tbody/tr/td[3]/a")).click();
//		//Taking the incident number
//				String inciNum1 = driver.findElement(By.id("incident.number")).getText();
		driver.findElement(By.id("sysverb_delete")).click();
		driver.findElement(By.xpath("//div[@id='delete_confirm_form']//button[@id='ok_button']")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//b[text()='All']")).click();
		WebElement search2 = driver.findElement(By.xpath("//input[@class='form-control']"));
		search2.sendKeys(inciNum);
		search2.sendKeys(Keys.ENTER);
		Thread.sleep(1000);
		String record = driver.findElement(By.xpath("//table[@id='incident_table']/tbody//td")).getText();
		if(record.equals("No records to display")) {
			System.out.println("The record deleted succesfully");
		}else {
			System.out.println("The record deletion is unsuccessful");
		}
	}
}
