package week4.day1;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Windows {
public static void main(String[] args) throws InterruptedException {
	//driver setup
	WebDriverManager.chromedriver().setup();
	//Closing the popups
		ChromeOptions options = new ChromeOptions(); 
		options.addArguments("--disable-notifications");
	//Launch the browser
	ChromeDriver driver = new ChromeDriver(options);
	
	//Load the url
	driver.get("https://www.irctc.co.in/nget/train-search");
	//Maximize the window
	driver.manage().window().maximize();
	//Closing the SweetAlert
	driver.findElement(By.xpath("//button[text()='OK']")).click();
	
	//Click on Flights
	driver.findElement(By.xpath("//a[contains(text(),'FLIGHTS')]")).click();
	//Move to the next window
	Set<String> windowHandles = driver.getWindowHandles();
	List<String> windows = new ArrayList<String>(windowHandles);
	//Getting the Title of the second opened window
	driver.switchTo().window(windows.get(1)); 
	String title = driver.getTitle();
	System.out.println(title);
	//Closing the parent window
	driver.switchTo().window(windows.get(0));
	driver.close();
	
	
}
}
