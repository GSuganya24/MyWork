package week4.day1;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class AlertFrame {
public static void main(String[] args) {
	WebDriverManager.chromedriver().setup();
	//Launch the broswer
	ChromeDriver driver = new ChromeDriver();
	//Load the url
	driver.get("https://www.w3schools.com/jsref/tryit.asp?filename=tryjsref_prompt");
	//Maximise the page
	driver.manage().window().maximize();
	//Enter the frame
	driver.switchTo().frame("iframeResult"); //Selecting frame using id
	driver.findElement(By.xpath("//button[text()='Try it']")).click();
	//Moving to text alert
	Alert set = driver.switchTo().alert();
	set.sendKeys("Suganya");
	set.accept();	
	
	String text = driver.findElement(By.id("demo")).getText();
	System.out.println(text);
	//Verifying the action
	if(text.contains("Suganya")) {
		System.out.println("Sucessful Action");
	}else {
		System.out.println("Unsuccessful action");
	}
	driver.close();
}
}
