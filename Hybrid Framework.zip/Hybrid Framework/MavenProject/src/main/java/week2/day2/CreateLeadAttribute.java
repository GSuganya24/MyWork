package week2.day2;

import org.openqa.selenium.By;
//import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

//Defining the elements using XMLPath
public class CreateLeadAttribute {
	public static void main(String[] args) {
		// Setup the driver
		WebDriverManager.chromedriver().setup();
		// System.setProperty("webdriver.chrome.driver","D:/MavenProject/chromedriver.exe");
		// (Can give this too)
		// Launch the Browser
		ChromeDriver driver = new ChromeDriver();
		// Load the url
		driver.get("http://leaftaps.com/opentaps/");
		// Maximize the browser
		driver.manage().window().maximize();
		// Get the title
		String title = driver.getTitle();
		System.out.println(title);

		driver.findElement(By.xpath("//input[contains(@id,'user')]")).sendKeys("DemoSalesManager");
		driver.findElement(By.xpath("//input[@class='inputLogin' and @id='password']")).sendKeys("crmsfa");
		driver.findElement(By.xpath("//input[@class='decorativeSubmit']")).click();
		driver.findElement(By.xpath("//a[text()[normalize-space()='CRM/SFA']]")).click();// To eliminate space
		driver.findElement(By.xpath("//a[text()='Leads']")).click();
		driver.findElement(By.xpath("//a[text()='Create Lead']")).click();
		driver.findElement(By.xpath("//input[@id='createLeadForm_companyName']")).sendKeys("IBM");
		driver.findElement(By.xpath("//input[@id='createLeadForm_firstName']")).sendKeys("Suganya");
		driver.findElement(By.xpath("//input[@id='createLeadForm_lastName']")).sendKeys("Gopalakrishnan");

	}
}
