package week2.day2;


import java.util.List;


import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class QuestionIRCTC {
public static void main(String[] args) throws InterruptedException {
	WebDriverManager.chromedriver().setup();
	ChromeDriver driver = new ChromeDriver();
	driver.get("https://www.irctc.co.in/nget/profile/user-registration");
	driver.manage().window().maximize();
	
	driver.findElement(By.xpath("//button[@type='submit' and @class='btn btn-primary']")).click();
	driver.findElement(By.xpath("//span[text()='Personal Details']")).click();
	
	Thread.sleep(1000);
	driver.findElement(By.xpath("//select[@formcontrolname='resCountry']")).click();
	WebElement ctry = driver.findElement(By.xpath("//select[@formcontrolname='resCountry']"));
	Select country = new Select(ctry);
	List<WebElement> options = country.getOptions();
	
	for(int i=0;i<options.size();i++) {
		String text = options.get(i).getText();
		System.out.println(text);
		int count = 0;
		for(int j=0;j<text.length();j++) {
		if(text.startsWith("E")) {
			count++;
			System.out.println("Country");}
		if(count == 2) {
			country.selectByIndex(i);
			break;
		}
		}
		
	}
	
}
}
