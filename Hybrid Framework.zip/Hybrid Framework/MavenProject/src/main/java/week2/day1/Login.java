package week2.day1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Login {
	public static void main(String[] args) {
		//Setup the driver
		WebDriverManager.chromedriver().setup();
		//System.setProperty("webdriver.chrome.driver","D:/MavenProject/chromedriver.exe"); (Can give this too)
		//Launch the Browser
		ChromeDriver driver = new ChromeDriver();
		//Load the url
		driver.get("http://leaftaps.com/opentaps/");
		//Maximise the browser
		driver.manage().window().maximize();
		//Get the title
		String title = driver.getTitle();
		System.out.println(title);
		//Enter the username
		WebElement userName = driver.findElement(By.id("username"));
		userName.sendKeys("DemoSalesManager");
		
		//Enter the password
		driver.findElement(By.id("password")).sendKeys("crmsfa");
		
		//Click on login button
		driver.findElement(By.className("decorativeSubmit")).click();
		
		//Click on CRM/SFA link
		driver.findElement(By.linkText("CRM/SFA")).click();
		
		//go to leads tab
		driver.findElement(By.linkText("Leads")).click();
		
		//Click Create Lead
		driver.findElement(By.linkText("Create Lead")).click();
		
		//Give the CompanyName
		driver.findElement(By.id("createLeadForm_companyName")).sendKeys("IBM");
		
		//Give the FirstName
		driver.findElement(By.id("createLeadForm_firstName")).sendKeys("Suganya");
		
		//Give the LastName
		driver.findElement(By.id("createLeadForm_lastName")).sendKeys("Gopalakrishnan");
		
		//Select any option from the source dropdown
		WebElement dd = driver.findElement(By.id("createLeadForm_dataSourceId"));
		    //Create Object for class 
		Select dropdown = new Select(dd);
		    //Choose the option
		dropdown.selectByVisibleText("Employee");
		
//		//Click the CreateLead Button
		driver.findElement(By.name("submitButton")).click();

//		//close the browser
		driver.close();
//		
	}

}
