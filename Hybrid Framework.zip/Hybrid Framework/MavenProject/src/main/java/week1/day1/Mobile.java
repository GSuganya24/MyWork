package week1.day1;

public class Mobile {
	//Global variables
	String mobileModel = "SamsungM51";
	int mobileWeight = 150;
	boolean isFullCharged = true;
	double mobileCost = 24500;
	
	public void makeCall() {
		System.out.println("Make a call");
	}
	public void sendMsg() {
		System.out.println("Send a new Message");
	}
 public static void main(String[] args) {
	Mobile obj = new Mobile();
	obj.makeCall();
	obj.sendMsg(); 
	
	//Calling the global variable into main method using object
	System.out.println(obj.mobileModel);
	System.out.println(obj.mobileWeight);
	System.out.println(obj.isFullCharged);
	System.out.println(obj.mobileCost);
	
	
	
	
 }
}
