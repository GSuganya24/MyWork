package week1.day1;

public class OddNumbers {
	public static void main(String[] args) {
		System.out.println("Printing Only Odd Numbers from 1 to 20");
		int a = 20;
		for (int i=1;i<a;i++) {
			if(i%2==1) {
				System.out.println("Odd Number : " +i);
				}
		}
			
	}

}
