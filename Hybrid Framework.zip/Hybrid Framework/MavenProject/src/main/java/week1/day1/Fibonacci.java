package week1.day1;

public class Fibonacci {
	public static void main(String[] args) {
		int firstnum = 0 ;
		int secnum = 1;
		int range = 8;
		int sum = 0;
		
		System.out.println("First Number : " +firstnum);
		for (int i=0;i<range;i++) {
			sum = firstnum + secnum;
			firstnum = secnum;
			secnum = sum;
		}
		System.out.println("Last Number : "+sum);
	}
	

}
