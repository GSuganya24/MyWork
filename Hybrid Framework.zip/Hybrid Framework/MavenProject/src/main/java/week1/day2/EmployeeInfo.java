package week1.day2;

public class EmployeeInfo {
	public void getEmployeeInfo(String name ,int empid) {
		System.out.println("Name : "+name+", Emp id : "+empid);
	}
	
	public static void main (String[] args) {
		EmployeeInfo ei = new EmployeeInfo();
		ei.getEmployeeInfo("Suganya", 23);
	}

}
