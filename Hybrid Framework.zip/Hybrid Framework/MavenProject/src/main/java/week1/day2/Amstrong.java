package week1.day2;

// Amstrong number of 153 --> (1*1*1)+(5*5*5)+(3*3*3) = 153

public class Amstrong {
	public static void main(String[] args) {
		int num = 153;
		int orgnum = num;
		int sum = 0;
		while(num > 0) {
			int r = num%10;
			 sum = sum + (r*r*r);
			 num = num/10;
			}
		System.out.println(sum);
		if (orgnum == sum) {
			System.out.println("Given Number is Amstrong");
		}else {
			System.out.println("Not an Amstrong Number");
		}
			
		
	}
}
