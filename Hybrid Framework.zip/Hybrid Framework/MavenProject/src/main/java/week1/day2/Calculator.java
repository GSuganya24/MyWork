package week1.day2;

public class Calculator {
	public int sum(int a, int b) {
		return a+b;
		}
	public double sub(double a, double b) {
		return a-b;
		}
	public double mult(double a, double b) {
		return a*b;
		}
	public int div(int a, int b) {
		return a/b;
		}
	
	public static void main(String[] args) {
		
		Calculator calc = new Calculator();
		int sum  = calc.sum(10, 5);
		System.out.println("Sum :" +sum);
		double sub = calc.sub(15.8, 5.6);
		System.out.println("Sub :" +sub);
		double mult = calc.mult(5.5, 6.4);
		System.out.println("Mul :" +mult);
		int div = calc.div(15,  3);
		System.out.println("Div :" +div);
		
	}

}
