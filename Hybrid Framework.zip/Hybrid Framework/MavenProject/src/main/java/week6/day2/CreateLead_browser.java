package week6.day2;

import org.openqa.selenium.By;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class CreateLead_browser extends BaseClass_Browser {
	@BeforeClass
	public void setUp() {
		filename = "CreateLead";
	}
	@Test(dataProvider = "fetchData")
public void createLead(String cName, String fName, String lName) {
		    driver.findElement(By.linkText("CRM/SFA")).click();
		    driver.findElement(By.linkText("Leads")).click();
		    driver.findElement(By.linkText("Create Lead")).click();
			//Fill the details of all the fields in Leadtab
			driver.findElement(By.id("createLeadForm_companyName")).sendKeys(cName);
			driver.findElement(By.id("createLeadForm_firstName")).sendKeys(fName);
			driver.findElement(By.id("createLeadForm_lastName")).sendKeys(lName);
		    driver.findElement(By.className("smallSubmit")).click();
		    //Printing the title of the page after clicking submit
		    String title = driver.getTitle();
		    System.out.println(title);
	}		    

}
