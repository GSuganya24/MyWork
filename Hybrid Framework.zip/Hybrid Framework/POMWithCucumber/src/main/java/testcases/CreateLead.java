package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseClass;
import pages.HomePage;

public class CreateLead extends BaseClass{
	
	@BeforeTest
	public void setUp() {
		fileName = "CreateLead";
	}

   @Test(dataProvider = "fetchData")
	public void runCreateLead(String cName, String fName, String lName) {
		
		new HomePage()
		.verifyHomePage()
		.clickCRMSFA()
		.clickLeads()
		.clickCreateLead()
		.enterCompanyName(cName)
		.enterFirstName(fName)
		.enterLastName(lName)
		.clickCreateLead()
		.verifyFirstName(fName);
	}
}
