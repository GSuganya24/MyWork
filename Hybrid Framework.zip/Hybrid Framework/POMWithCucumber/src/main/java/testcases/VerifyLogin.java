package testcases;

import org.testng.annotations.Test;

import base.BaseClass;
import pages.HomePage;
import pages.LoginPage;

public class VerifyLogin extends BaseClass{

	@Test(dataProvider = "fetchData")
	public void runVerifyLogin() {
//		LoginPage lp = new LoginPage();
		
		new HomePage()
		.verifyHomePage()
		.clickCRMSFA();
		
	}
}
