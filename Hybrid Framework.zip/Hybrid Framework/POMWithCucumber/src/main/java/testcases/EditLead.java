package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseClass;
import pages.HomePage;


public class EditLead extends BaseClass {
	@BeforeTest
	public void setUp1() {
		fileName = "EditLead";
	}
	@Test(dataProvider = "fetchData")
	public void editLead(String fName,String cName) throws InterruptedException {
     new HomePage()
	.verifyHomePage()
	.clickCRMSFA()
	.verifyLeadsTab()
	.clickLeads()
	.verifyTitle()
	.clickFindLead()
	.searchByFirstName(fName)
	.clickFirstResultingLead()
	.clickEditButton()
	.changeCompanyName(cName)
	.clickUpdateButton()
	.verifyCompanyName(cName);	
	}

}
