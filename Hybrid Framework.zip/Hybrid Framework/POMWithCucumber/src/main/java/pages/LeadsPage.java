package pages;

import org.openqa.selenium.By;
import base.BaseClass;

public class LeadsPage extends BaseClass{

	public LeadsPage verifyTitle() {
		String title = getDriver().getTitle();
		if(title.equalsIgnoreCase("My Leads | opentaps CRM")) {
			System.out.println("Moved to the My Leads Page");
		}else {
			System.out.println("Moved to the page "+title);
		}
		return this;
	}
	public CreateLeadPage clickCreateLead() {
		getDriver().findElement(By.linkText(prop1.getProperty("Create_Lead_Link_Text"))).click();
		return new CreateLeadPage();
	}
	public FindLeadsPage clickFindLead() {
		getDriver().findElement(By.xpath("//a[text()='Find Leads']")).click();
		return new FindLeadsPage();
	}
	
}
