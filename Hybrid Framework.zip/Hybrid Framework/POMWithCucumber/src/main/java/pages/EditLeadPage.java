package pages;

import org.openqa.selenium.By;

import base.BaseClass;

public class EditLeadPage extends BaseClass {
	public EditLeadPage changeCompanyName(String cName) {
		getDriver().findElement(By.xpath("//input[@id='updateLeadForm_companyName']")).clear();
		getDriver().findElement(By.xpath("//input[@id='updateLeadForm_companyName']")).sendKeys(cName);
		return this;
	}
	public ViewLeadPage clickUpdateButton() {
		getDriver().findElement(By.xpath("//input[@value = 'Update']")).click();
		return new ViewLeadPage();
	}

}
