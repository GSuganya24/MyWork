package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Assert;

import base.BaseClass;

public class FindLeadsPage extends BaseClass {
	
	public FindLeadsPage searchByFirstName(String fName) throws InterruptedException {
		getDriver().findElement(By.xpath("//div[@class='x-form-item x-tab-item']//input[@name='firstName']")).sendKeys(fName);
		getDriver().findElement(By.xpath("//button[text()='Find Leads']")).click();
		Thread.sleep(1000);
		return this;
	}
	
	public ViewLeadPage clickFirstResultingLead() {
		leadID = getDriver().findElement(By.xpath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a")).getText();
		firstName = getDriver().findElement(By.xpath("//div[@class='x-grid3-cell-inner x-grid3-col-firstName']/a")).getText();
		System.out.println(firstName);
		getDriver().findElement(By.xpath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a")).click();
		return new ViewLeadPage();
	}
//	public FindLeadsPage searchByEmail(String eMail) throws InterruptedException {
//		getDriver().findElement(By.xpath("//span[text()='Email']")).click();
//		getDriver().findElement(By.xpath("//div[@class='x-form-element']/input[@name='emailAddress']"))
//		.sendKeys(eMail);
//		driver.findElement(By.xpath("//button[text()='Find Leads']")).click();
//		Thread.sleep(1000);
//		return this;
//	}
//	public FindLeadsPage verifyLeadId() throws InterruptedException {
//		driver.findElement(By.xpath("//input[@name='id']")).sendKeys(leadID);
//		driver.findElement(By.xpath("//button[text()='Find Leads']")).click();
//		Thread.sleep(1000);
//		String text = driver.findElement(By.className("x-paging-info")).getText();
//		Assert.assertEquals(text, "No records to display");
//		System.out.println("Merge Lead is Successful");
//		return this;
//	}
//	public FindLeadsPage searchByPhoneNumber(String num) throws InterruptedException {
//		driver.findElement(By.xpath("//span[text()='Phone']")).click();
//		driver.findElement(By.xpath("//input[@name='phoneNumber']")).sendKeys(num);
//		driver.findElement(By.xpath("//button[text()='Find Leads']")).click();
//		Thread.sleep(1000);
//		return this;
//	}

	
}

