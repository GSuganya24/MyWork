package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.testng.Assert;

import base.BaseClass;
import io.cucumber.java.en.Then;

public class HomePage extends BaseClass{
//	@FindBy(how = How.LINK_TEXT, using = "CRM/SFA") WebElement eleCRMSFA;
	
	public MyHomePage clickCRMSFA() {
		getDriver().findElement(By.linkText("CRM/SFA")).click();
//		eleCRMSFA.click();
		return new MyHomePage();
	}
	
	@Then("Homepage should be present")
	public HomePage verifyHomePage() {
		boolean displayed = getDriver().findElement(By.linkText("CRM/SFA")).isDisplayed();
		Assert.assertTrue(displayed);
		return this;
	}
}
