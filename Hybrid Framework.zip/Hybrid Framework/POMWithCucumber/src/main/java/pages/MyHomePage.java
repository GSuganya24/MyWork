package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Assert;

import base.BaseClass;

public class MyHomePage extends BaseClass{

	public LeadsPage clickLeads() {
		getDriver().findElement(By.linkText(prop1.getProperty("Leads_Link_Text"))).click();
		return new LeadsPage();
	}
	public MyHomePage verifyLeadsTab() {
		boolean lead = getDriver().findElement(By.linkText("Leads")).isDisplayed();
		Assert.assertTrue(lead);
		return this;
	}
}
