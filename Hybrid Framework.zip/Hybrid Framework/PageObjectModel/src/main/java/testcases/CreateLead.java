package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;

public class CreateLead extends BaseClass{
	@BeforeTest
	public void setup() {
		fileName = "CreateLead";
	}
@Test(dataProvider = "fetchdata")
public void createLead(String cName, String fName, String lName, String eMail, String num) {
	LoginPage lp = new LoginPage(driver);
	lp.enterUsername()
	.enterPassword()
	.clickLoginButton()
	.verifyHomePage()
	.clickCRMSFA()
	.verifyLeadsTab()
	.clickLeadsTab()
	.verifyTitle()
	.clickCreateLead()
	.enterCompanyName(cName)
	.enterFirstName(fName)
	.enterLastName(lName)
	.enterEmailId(eMail)
	.enterPhoneNumber(num)
	.clickSubmitButton()
	.verifyFirstName();
}
}
