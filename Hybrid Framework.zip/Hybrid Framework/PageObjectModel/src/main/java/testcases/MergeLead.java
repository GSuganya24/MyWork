package testcases;

import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;

public class MergeLead extends BaseClass {
	@Test
	public void mergeLead() throws InterruptedException {
		LoginPage lp = new LoginPage(driver);
		lp.enterUsername()
		.enterPassword()
		.clickLoginButton()
		.clickCRMSFA()
		.clickLeadsTab()
		.mergeLead()
		.enterFromLead()
		.enterToLead()
		.clickMergeButton()
		.clickFindLead()
		.verifyLeadId();
	}

}
