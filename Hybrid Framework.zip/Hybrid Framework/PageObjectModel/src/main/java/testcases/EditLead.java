package testcases;

import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;

public class EditLead extends BaseClass {
	@Test
	public void editLead() throws InterruptedException {
	LoginPage lp = new LoginPage(driver);
	lp.enterUsername()
	.enterPassword()
	.clickLoginButton()
	.verifyHomePage()
	.clickCRMSFA()
	.verifyLeadsTab()
	.clickLeadsTab()
	.verifyTitle()
	.clickFindLead()
	.searchByFirstName()
	.clickFirstResultingLead()
	.clickEditButton()
	.changeCompanyName()
	.clickUpdateButton()
	.verifyCompanyName();	
	}

}
