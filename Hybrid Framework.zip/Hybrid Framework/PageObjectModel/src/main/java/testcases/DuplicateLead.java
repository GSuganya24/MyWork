package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;

public class DuplicateLead extends BaseClass {
	@BeforeTest
	public void fileName() {
		fileName = "DuplicateLead";
	}

	@Test(dataProvider = "fetchdata")
	public void duplicateLead(String email) throws InterruptedException {
		LoginPage lp = new LoginPage(driver);
		lp.enterUsername()
		.enterPassword()
		.clickLoginButton()
		.clickCRMSFA()
		.clickLeadsTab()
		.clickFindLead()
		.searchByEmail(email)
		.clickFirstResultingLead()
		.clickDuplicateLead()
		.createDuplicateLead()
		.verifyFirstName();
	}

}
