package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import base.BaseClass;

public class CreateLeadsPage extends BaseClass {
	public CreateLeadsPage(RemoteWebDriver driver) {
		this.driver=driver;
	}
	public CreateLeadsPage enterCompanyName(String cName) {
		driver.findElement(By.id("createLeadForm_companyName")).sendKeys(cName);
		return this;
	}
	public CreateLeadsPage enterFirstName(String fName) {
		firstName = fName;
		driver.findElement(By.id("createLeadForm_firstName")).sendKeys(fName); 
		return this;
	}
	public CreateLeadsPage enterLastName(String lName) {
		driver.findElement(By.id("createLeadForm_lastName")).sendKeys(lName);
		return this;
		
	}
	public CreateLeadsPage enterEmailId(String eMail) {
		driver.findElement(By.id("createLeadForm_primaryEmail")).sendKeys(eMail);
		return this;
	}
	public CreateLeadsPage enterPhoneNumber(String num) {
		phoneNumber = num;
		driver.findElement(By.id("createLeadForm_primaryPhoneNumber")).sendKeys(num);
		return this;
	}

	public ViewLeadPage clickSubmitButton() {
		driver.findElement(By.className("smallSubmit")).click();
		return new ViewLeadPage(driver);
	}

}
