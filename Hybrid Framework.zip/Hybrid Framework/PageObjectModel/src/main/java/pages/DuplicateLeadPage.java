package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import base.BaseClass;

public class DuplicateLeadPage extends BaseClass{
	public DuplicateLeadPage(RemoteWebDriver driver) {
		this.driver=driver;
	}
	
	public ViewLeadPage createDuplicateLead() throws InterruptedException {
    driver.findElement(By.xpath("//input[@value='Create Lead']")).click();
	Thread.sleep(2000);
	return new ViewLeadPage(driver);
	}

}
