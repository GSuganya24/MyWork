package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import base.BaseClass;

public class EditLeadPage extends BaseClass {
	public EditLeadPage(RemoteWebDriver driver) {
		this.driver= driver;
	}
	public EditLeadPage changeCompanyName() {
		driver.findElement(By.xpath("//input[@id='updateLeadForm_companyName']")).clear();
		driver.findElement(By.xpath("//input[@id='updateLeadForm_companyName']")).sendKeys("Testleaf");
		return this;
	}
	public ViewLeadPage clickUpdateButton() {
		driver.findElement(By.xpath("//input[@value = 'Update']")).click();
		return new ViewLeadPage(driver);
	}

}
