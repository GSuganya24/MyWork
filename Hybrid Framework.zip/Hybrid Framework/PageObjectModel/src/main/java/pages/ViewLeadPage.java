package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Assert;

import base.BaseClass;

public class ViewLeadPage extends BaseClass{
	public ViewLeadPage(RemoteWebDriver driver) {
		this.driver = driver;
	}
	public ViewLeadPage verifyFirstName() {
		String name = driver.findElement(By.id("viewLead_firstName_sp")).getText();
		Assert.assertEquals(name, firstName);
		System.out.println("Verified the FirstName. Leads Creation is successful");
		return this;
	}
	public EditLeadPage clickEditButton() {
		driver.findElement(By.xpath("//div[@class='frameSectionExtra']/a[text()='Edit']")).click();
		return new EditLeadPage(driver);
	}
	
	public ViewLeadPage verifyCompanyName() {
		String verify = driver.findElement(By.xpath("//span[@id='viewLead_companyName_sp']")).getText();
		if(verify.contains("Testleaf")) {
			System.out.println("Updated Company Name");
		}else {
			System.out.println("Compay Name not updated");
		}
		return this;
	}
	public DuplicateLeadPage clickDuplicateLead(){
		driver.findElement(By.xpath("//a[text()='Duplicate Lead']")).click();
		return new DuplicateLeadPage(driver);
	}
	public LeadsPage clickDeleteButton() {
		driver.findElement(By.xpath("//a[text()='Delete']")).click();
		return new LeadsPage(driver);
	}
	

}
