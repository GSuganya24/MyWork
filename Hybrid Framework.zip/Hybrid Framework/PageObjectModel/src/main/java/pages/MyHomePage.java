package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Assert;

import base.BaseClass;

public class MyHomePage extends BaseClass{
	public MyHomePage(RemoteWebDriver driver) {
		this.driver=driver;
	}
	public LeadsPage clickLeadsTab() {
		driver.findElement(By.linkText("Leads")).click();
		return new LeadsPage(driver);
	}
	public MyHomePage verifyLeadsTab() {
		boolean lead = driver.findElement(By.linkText("Leads")).isDisplayed();
		Assert.assertTrue(lead);
		return this;
	}

}
