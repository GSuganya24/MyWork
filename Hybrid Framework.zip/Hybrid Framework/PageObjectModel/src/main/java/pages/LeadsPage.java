package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import base.BaseClass;

public class LeadsPage extends BaseClass {
	public LeadsPage(RemoteWebDriver driver) {
		this.driver=driver;
	}
	public LeadsPage verifyTitle() {
		String title = driver.getTitle();
		if(title.equalsIgnoreCase("My Leads | opentaps CRM")) {
			System.out.println("Moved to the My Leads Page");
		}else {
			System.out.println("Moved to the page "+title);
		}
		return this;
	}
	public CreateLeadsPage clickCreateLead() {
		driver.findElement(By.linkText("Create Lead")).click();
		return new CreateLeadsPage(driver);
	}
	public FindLeadsPage clickFindLead() {
		driver.findElement(By.xpath("//a[text()='Find Leads']")).click();
		return new FindLeadsPage(driver);
	}
	public MergeLeadsPage mergeLead() {
		driver.findElement(By.linkText("Merge Leads")).click();
		return new MergeLeadsPage(driver);
	}

}
