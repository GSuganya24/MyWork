package base;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;

import io.github.bonigarcia.wdm.WebDriverManager;

public class BaseClass {
	public RemoteWebDriver driver;
	public String fileName;
	public static String firstName;
	public static String leadID;
	public static String phoneNumber;
	@BeforeMethod
	public void precondition() {
		  WebDriverManager.chromedriver().setup();
			driver = new ChromeDriver();
			driver.manage().window().maximize();
			driver.get("http://leaftaps.com/opentaps/");
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
	}
	@AfterMethod
	public void postcondition() {
		driver.close();
	}
	@DataProvider(name = "fetchdata")
	public String[][] senddata() throws IOException{
		return utils.ReadXcel.readXcel(fileName);
	}

}
